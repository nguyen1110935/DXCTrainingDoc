myApp.service("GreetingService", function () {  // Contructor function
    this.name = "My Name";
    this.greetingMessage = "Hello";
});
